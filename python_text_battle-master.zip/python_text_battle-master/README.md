## RPG Battle
##### A python implementation of a text based/terminal battle game

Ended up having to rewrite a good portion of it, so I've improved quite a bit of it.  Now with awesome HP/MP bars, multiple enemies and party members, and items.

![Alt text](/images/rpgbattle-screen.png?raw=true "2017 update")
